# Krea2 RunPod corrected candidate (NOT live-tested)

This version patches the generated Dockerfile and API workflow. It is **not yet a verified working image**.

Changes:
- Fixed first Krea2 file from `models/Unknown` to `models/diffusion_models` and standardized API UNET name.
- Removed redundant `Krea2 jibMix` model copy and unused INT8 diffusion download.
- Added 6 LoRA weight downloads. Check source access, license and availability before building.
- Restored `lora_1`..`lora_6` dictionary inputs in API node 140 so Telegram can toggle `on` per job.

Potential issues to test:
- `TextGenerate` and its compatible Qwen encoder support in the selected ComfyUI build.
- Python dependency installation for custom nodes.
- Whether the two optional LoRAs and other downloads are publicly accessible.
- The workflow's 3 original input images and initial image naming.
- The original graph and API graph now differ in loader filename; use the corrected API workflow for requests.

The RunPod official worker base image includes a serverless handler, but the GitHub repo static checker might still flag a missing `runpod.serverless.start()` call. A successful image build and one real API job are required to establish compatibility.

Deploy the *built and published container image* as a queue endpoint; don't assume uploading the JSON alone is a deployment.
